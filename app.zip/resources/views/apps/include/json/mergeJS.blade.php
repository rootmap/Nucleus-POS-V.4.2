<script type="text/javascript">
    $(document).ready(function(){

		    //---------------------Test Ajax New Product Start---------------------//
            $("#repair_clear").click(function(){ 
                $("#merge").hide();
                $("#clearmerge").show();
            });

            $("#merge_repair").click(function(){ 
                $("#merge").show();
                $("#clearmerge").hide();
            });

            
            //step3 end
	});

</script>