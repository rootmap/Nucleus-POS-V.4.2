<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SquareConnect extends Model
{
    protected $table= "squareup_connects";
}
