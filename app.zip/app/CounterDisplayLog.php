<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CounterDisplayLog extends Model
{
    //
}
