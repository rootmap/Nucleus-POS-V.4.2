<?php

namespace App\Http\Controllers;

use App\SessionInvoice;
use Illuminate\Http\Request;

class SessionInvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SessionInvoice  $sessionInvoice
     * @return \Illuminate\Http\Response
     */
    public function show(SessionInvoice $sessionInvoice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SessionInvoice  $sessionInvoice
     * @return \Illuminate\Http\Response
     */
    public function edit(SessionInvoice $sessionInvoice)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SessionInvoice  $sessionInvoice
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SessionInvoice $sessionInvoice)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SessionInvoice  $sessionInvoice
     * @return \Illuminate\Http\Response
     */
    public function destroy(SessionInvoice $sessionInvoice)
    {
        //
    }
}
