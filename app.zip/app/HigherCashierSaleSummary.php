<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HigherCashierSaleSummary extends Model
{
    //
}
