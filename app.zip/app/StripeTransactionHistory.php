<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StripeTransactionHistory extends Model
{
    protected $table = "stripe_transaction_histories";
}
